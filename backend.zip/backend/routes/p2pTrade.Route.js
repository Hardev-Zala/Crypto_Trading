import express from "express";
import protectRoute from "../middleware/protectRoute.js";
import { Order } from "../model/user.model.js";

const router = express.Router();

// Place a new order
router.post("/order", protectRoute, async (req, res) => {
    const { type, symbol, amount, price } = req.body;
    try {
        const order = await Order.create({
            user: req.user.id,
            type,
            symbol,
            amount,
            price
        });
        res.status(201).json(order);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

router.get("/orders", async (req, res) => {
    try {
        const orders = await Order.find({ status: "open" }).populate("user", "email");
        res.json(orders);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;