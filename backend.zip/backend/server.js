// import express from "express"
// import { ENV_VARS } from "./config/envVars.js"
// import router from "./routes/auth.Route.js"
// import connect from "./config/db.js"
// import cookieParser from "cookie-parser"
// import fetch from "./routes/fetch.Route.js"
// import cors from "cors"
// import { startWebSocket } from './utils/websocket.js';
// // import http from "http";


// const app = express()
// const {PORT} = ENV_VARS 
// connect()

// app.use(cors({origin:"http://localhost:5173"}))
// app.use(express.json())
// app.use(cookieParser())

// app.use('/api/v1/auth',router)
// app.use('/api/v1/fetch',fetch)

// app.listen(PORT,()=>{
//   console.log(`server running at http://localhost:${PORT}`);
//   // setup periodic price updater
//   // FetchingPrices.setupPriceUpdater();


//   // updateData(); // Fetch data on server start

// })

// ---------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------

// server.js
import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { getStockData, connectWebSocket, closeWebSocket } from './utils/twelveData.js';
import router from "./routes/auth.Route.js";
import p2pTrade from "./routes/p2pTrade.Route.js";
import connect from "./config/db.js";
import cookieParser from "cookie-parser";
import fetch from "./routes/fetch.Route.js";
import cors from "cors";
import { Order } from "./model/user.model.js";

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

connect();

let clients = [];

app.use(cors({ origin: "http://localhost:5173", credentials: true }));
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

app.use('/api/v1/auth', router);
app.use('/api/v1/fetch', fetch);
app.use("/api/v1/p2p", p2pTrade);

wss.on('connection', (ws) => {
    console.log('Client connected');
    clients.push(ws);

    ws.on('close', () => {
        console.log('Client disconnected');
        clients = clients.filter(client => client !== ws);
    });

    ws.on("error", (error) => {
        console.error("WebSocket error:", error);
    });

    ws.on("message", async (message) => {
        const data = JSON.parse(message);
        if (data.type === "placeOrder") {
            await placeOrder(data);
        }
        if (data.type === "matchOrder") {
            await matchOrders(data.symbol);
        }
    });
});

const broadcastData = (data) => {
    clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(data));
        }
    });
};

const placeOrder = async (orderData) => {
    try {
        const newOrder = new Order({
            user: orderData.userId,
            symbol: orderData.symbol,
            type: orderData.orderType,
            price: orderData.price,
            amount: orderData.amount,
            status: "open",
            entryPrice: orderData.price,
        });
        await newOrder.save();
        broadcastData({ type: "orderPlaced", order: newOrder });
    } catch (error) {
        console.error("Error placing order:", error);
    }
};

const matchOrders = async (symbol) => {
    try {
        let buyOrders = await Order.find({ symbol, type: "buy", status: "open" }).sort({ price: -1 });
        let sellOrders = await Order.find({ symbol, type: "sell", status: "open" }).sort({ price: 1 });
        
        while (buyOrders.length > 0 && sellOrders.length > 0) {
            let buyOrder = buyOrders[0];
            let sellOrder = sellOrders[0];
            
            if (buyOrder.price >= sellOrder.price) {
                let tradeAmount = Math.min(buyOrder.amount, sellOrder.amount);
                
                buyOrder.amount -= tradeAmount;
                sellOrder.amount -= tradeAmount;
                
                if (buyOrder.amount === 0) buyOrder.status = "completed";
                if (sellOrder.amount === 0) sellOrder.status = "completed";
                
                await buyOrder.save();
                await sellOrder.save();
                
                broadcastData({ type: "tradeExecuted", symbol, tradeAmount, price: sellOrder.price });
            }
            
            buyOrders = await Order.find({ symbol, type: "buy", status: "open" }).sort({ price: -1 });
            sellOrders = await Order.find({ symbol, type: "sell", status: "open" }).sort({ price: 1 });
        }
    } catch (error) {
        console.error("Error matching orders:", error);
    }
};

const symbols = [
    "BINANCE:BNBUSDT", "BINANCE:BTCUSDT", "BINANCE:ETHUSDT",
    "BINANCE:DOGEUSDT", "BINANCE:SHIBUSDT", "BINANCE:LTCUSDT",
    "BINANCE:DOTUSDT", "BINANCE:MATICUSDT", "BINANCE:SOLUSDT", "BINANCE:ADAUSDT", "BINANCE:XRPUSDT"
];

setInterval(async () => {
    try {
        const stockData = await getStockData(symbols);
        broadcastData(stockData);
    } catch (error) {
        console.error('Error fetching data:', error.message);
    }
}, 60000);

connectWebSocket(symbols, broadcastData);

process.on("SIGINT", () => {
    closeWebSocket();
    process.exit();
});

const PORT = process.env.PORT || 3500;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// ✅ **NEW: Binance WebSocket Connection**
// const binanceSymbols = ["btcusdt", "ethusdt", "bnbusdt", "dogeusdt", "shibusdt", "ltcusdt", "dotusdt", "maticusdt", "solusdt", "adausdt", "xrpusdt"];
// const binanceWS = new WebSocket(`wss://stream.binance.com:9443/ws/${binanceSymbols.map(s => s + "@trade").join("/")}`);

// binanceWS.onmessage = (event) => {
//     try {
//         const data = JSON.parse(event.data);
//         broadcastData(data); // Send Binance data to frontend clients
//     } catch (error) {
//         console.error("Error parsing Binance WebSocket data:", error);
//     }
// };

// binanceWS.onopen = () => {
//     console.log("Connected to Binance WebSocket");
// };

// binanceWS.onerror = (error) => {
//     console.error("Binance WebSocket error:", error);
// };

// binanceWS.onclose = () => {
//     console.log("Binance WebSocket closed");
// };


// const symbols = ["AAPL", "GOOGL", "MSFT", "BINANCE:BTCUSDT", "BINANCE:ETHUSDT", "^GSPC", "^IXIC"];
// const stockSymbols = ['AAPL','NASDAQ','GOOGL'];

// // Connect to Intrinio WebSocket for real-time updates
// connectIntrinioWebSocket(stockSymbols, broadcastData);

// // Close WebSocket on server shutdown
// process.on('SIGINT', () => {
//     closeIntrinioWebSocket();
//     process.exit();
// });